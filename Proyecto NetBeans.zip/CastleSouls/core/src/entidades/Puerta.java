/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.scenes.scene2d.Actor;

/**
 *
 * @author Jose A
 */
public class Puerta extends Actor{
    TextureRegion stand;
 
    public TiledMapTileLayer layer;


    public Puerta() {
        final float width = 32;
        final float height = 64;
        this.setSize(1, height / width);

        Texture textura = new Texture("tileds/puerta.png");
        TextureRegion[][] grid = TextureRegion.split(textura, (int) width, (int) height);
        
        stand = grid[0][0];
    }

    public void act(float delta) {
   
        float x = this.getX();
        float y = this.getY();
        this.setPosition(x, y);

    }

    public void draw(Batch batch, float parentAlpha) {
        TextureRegion frame;
        frame = stand;
        batch.draw(frame, this.getX(), this.getY(), this.getWidth(), this.getHeight());
    }
   
 
   public Rectangle getBounds() {
        return new Rectangle(this.getX(), this.getY(), this.getWidth(), this.getHeight());
    }
    
}
