/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.mygdx.game.sonidos;

/**
 *
 * @author Jose A
 */
public class Cofre extends Actor{
    TextureRegion cerrado, abierto;
 
    public TiledMapTileLayer layer;
    public boolean isCerrado;


    public Cofre() {
        final float width = 50;
        final float height = 62;
        this.setSize(1, height / width);

        Texture textura = new Texture("tileds/cofre.png");
        TextureRegion[][] grid = TextureRegion.split(textura, (int) width, (int) height);
        
        this.isCerrado=true;
        cerrado = grid[0][0];
        abierto = grid[0][1];
    }

    public void act(float delta) {
   
        float x = this.getX();
        float y = this.getY();
        this.setPosition(x, y);

    }

    public void draw(Batch batch, float parentAlpha) {
        TextureRegion frame;
        if(isCerrado==true){
            frame=cerrado;
        }
        else
            frame=abierto;
        
        batch.draw(frame, this.getX(), this.getY(), this.getWidth(), this.getHeight());
    }
   
 
   public Rectangle getBounds() {
        return new Rectangle(this.getX(), this.getY(), this.getWidth(), this.getHeight());
    }
   
   public void abrir(){
       sonidos.COFRE.play();
       this.isCerrado=false;
   }
    
}
