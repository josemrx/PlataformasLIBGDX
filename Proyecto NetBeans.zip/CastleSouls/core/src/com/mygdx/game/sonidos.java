/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mygdx.game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;

/**
 *
 * @author Jose A
 */
public class sonidos {
    
    // Música
    public static Music FOREST = Gdx.audio.newMusic(Gdx.files.internal("sounds/forest.mp3"));
    public static Music CASTLE= Gdx.audio.newMusic(Gdx.files.internal("sounds/castle.mp3"));
    // Efectos de sonido
    public static Sound SALTO = Gdx.audio.newSound(Gdx.files.internal("sounds/salto.wav"));
    public static Sound DAÑO = Gdx.audio.newSound(Gdx.files.internal("sounds/damage.wav"));
    public static Sound RUPIA = Gdx.audio.newSound(Gdx.files.internal("sounds/rupia.wav"));
    public static Sound CORAZON = Gdx.audio.newSound(Gdx.files.internal("sounds/corazon.wav"));
    public static Sound GAMEOVER = Gdx.audio.newSound(Gdx.files.internal("sounds/gameOver.wav"));
    public static Sound COFRE = Gdx.audio.newSound(Gdx.files.internal("sounds/cofre.wav"));
   
    public static void pause() {
        FOREST.dispose();
        CASTLE.dispose();
    }

    public static void resume() {
        FOREST = Gdx.audio.newMusic(Gdx.files.internal("sounds/forest.mp3"));
        CASTLE = Gdx.audio.newMusic(Gdx.files.internal("sounds/forest.mp3"));
    }
}
