package com.mygdx.game;

import pantallas.InicioScreen;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;



public class MyGdxGame extends Game {
        public SpriteBatch batch;
        static public int WIDTH = 800, HEIGHT = 600;
    
	public void create() {
            batch = new SpriteBatch();
            this.setScreen(new InicioScreen(this));
	}
}