/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pantallas;

/**
 *
 * @author Jose A
 */
import entidades.Bub;
import entidades.Jugador;
import entidades.Zombi;
import com.badlogic.gdx.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.maps.tiled.*;
import com.badlogic.gdx.maps.tiled.renderers.*;
import com.badlogic.gdx.scenes.scene2d.*;
import com.mygdx.game.MyGdxGame;
import com.mygdx.game.sonidos;
import entidades.Cofre;
import entidades.Corazon;
import entidades.Roto2;
import entidades.Rupia;

public class Stage2Screen implements Screen {
    final MyGdxGame game;
    Stage stage;
    TiledMap map;
    OrthogonalTiledMapRenderer renderer;
    OrthographicCamera camera;
    Jugador jugador;
    
    
    public Stage2Screen(MyGdxGame game, Jugador jug){
        this.game=game;
        this.jugador=jug;
    }

    public void show() {
        sonidos.CASTLE.play();
        map = new TmxMapLoader().load("tileds/level2.tmx");
        final float pixelsPerTile = 16;
        renderer = new OrthogonalTiledMapRenderer(map, 1 / pixelsPerTile);
        camera = new OrthographicCamera();

        stage = new Stage();
        stage.getViewport().setCamera(camera);
        añadeCofre(15, 2);
        añadeCofre(17, 2);
        añadeCofre(19, 2);
        añadeCofre(83, 10);
        añadeZombi(48);
        añadeBub(60);
        añadeRoto2(115);
        añadeRoto2(122);
        añadeRoto2(129);
        añadeZombi(192);
        añadeZombi(164);
        añadeBub(210);
        jugador.layer = (TiledMapTileLayer) map.getLayers().get("walls");
        jugador.setPosition(12, 2);
        stage.addActor(jugador);
        
    }

    public void render(float delta) {
        Gdx.gl.glClearColor(0, 0, 0, 0);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        camera.position.x = jugador.getX();
        camera.update();

        renderer.setView(camera);
        renderer.render();

        stage.act(delta);
        stage.draw();
        this.colisiones();
        this.IA();
        this.fin();
       
    }

    public void dispose() {
        sonidos.CASTLE.dispose();
    }

    public void hide() {
    }

    public void pause() {
    }

    public void resize(int width, int height) {
        camera.setToOrtho(false, 20 * width / height, 20);
    }

    public void resume() {
    }
    
    private void fin(){
        if(jugador.vida<=0){
            game.setScreen(new GameOverScreen(game));
            dispose();
        }
    }
    
    private void IA(){
         for(int i =0;i<stage.getActors().size;i++){
             Actor obtenido = stage.getActors().get(i);
             if(stage.getActors().get(i) instanceof Bub){
                 ((Bub)obtenido).miraJugador(jugador);
             }
         }
    }
   private void colisiones(){
        for(int i =0;i<stage.getActors().size;i++){
            Actor obtenido = stage.getActors().get(i);
            
            if(obtenido instanceof Zombi){
                if(((Zombi)obtenido).getBounds().overlaps(jugador.getBounds())){
                    jugador.setDaño();
                }
            }
            
             if(obtenido instanceof Bub){
                if(((Bub)obtenido).getBounds().overlaps(jugador.getBounds())){
                    jugador.setDaño();
                }
             }
             if(obtenido instanceof Roto2){
                if(((Roto2)obtenido).getBounds().overlaps(jugador.getBounds())){
                    jugador.setDaño();
                }
             }
             if(obtenido instanceof Corazon){
                if(((Corazon)obtenido).getBounds().overlaps(jugador.getBounds())){
                    sonidos.CORAZON.play();
                    jugador.vida++;
                    obtenido.remove();
                }
             }
             if(obtenido instanceof Rupia){
                if(((Rupia)obtenido).getBounds().overlaps(jugador.getBounds())){
                    sonidos.RUPIA.play();
                    jugador.rupias++;
                    obtenido.remove();
                }
             }
             if(obtenido instanceof Cofre){
                if(((Cofre)obtenido).getBounds().overlaps(jugador.getBounds())&& Gdx.input.isKeyPressed(Input.Keys.DOWN)){
                    if(((Cofre) obtenido).isCerrado){
                        if(jugador.vida>1){
                             añadeRupia((int) obtenido.getX(), (int)obtenido.getY()+3);
                        }
                        else
                            añadeCorazon((int) obtenido.getX(), (int)obtenido.getY()+3);
                        ((Cofre) obtenido).abrir();
                    }  
                }
             }
   
        }
    }
    
    private void añadeZombi(int posX){
        
        Zombi zombi = new Zombi();
        zombi.layer = (TiledMapTileLayer) map.getLayers().get("walls");
        zombi.setPosition(posX, 2);
        stage.addActor(zombi);
        
    }
    private void añadeBub(int posX){
        Bub buble = new Bub();
        buble.layer = (TiledMapTileLayer) map.getLayers().get("walls");
        buble.setPosition(posX, 2);
        stage.addActor(buble);
        
    }
    private void añadeCorazon(int posX, int posY){
        Corazon corazon = new Corazon();
        corazon.layer = (TiledMapTileLayer) map.getLayers().get("walls");
        corazon.setPosition(posX, posY);
        stage.addActor(corazon);
        
    }
    private void añadeCofre(int posX, int posY){
        Cofre c = new Cofre();
        c.layer = (TiledMapTileLayer) map.getLayers().get("walls");
        c.setPosition(posX, posY);
        stage.addActor(c);
        
    }
    private void añadeRupia(int posX, int posY){
        Rupia rupia = new Rupia();
        rupia.layer = (TiledMapTileLayer) map.getLayers().get("walls");
        rupia.setPosition(posX, posY);
        stage.addActor(rupia);
        
    }
    private void añadeRoto2(int posX){
        
        Roto2 roto = new Roto2();
        roto.layer = (TiledMapTileLayer) map.getLayers().get("walls");
        roto.setPosition(posX, 10);
        stage.addActor(roto);
        
    }
    
    
    
}

